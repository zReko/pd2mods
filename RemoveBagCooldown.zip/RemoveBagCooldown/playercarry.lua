function PlayerStandard:_action_interact_forbidden()
	local action_forbidden = self:chk_action_forbidden("interact") or self._unit:base():stats_screen_visible() or self:_interacting() or self._ext_movement:has_carry_restriction() or self:is_deploying() or self:_is_throwing_projectile() or self:_is_meleeing() or self:_on_zipline()
	return action_forbidden
end
function PlayerManager:carry_blocked_by_cooldown()
	return false
end
